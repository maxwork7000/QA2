package core;

/**
 * Hello world!
 *
 */
public class CLA_S 
{
    public static void main( String[] args )
    {
        System.out.println("Hello Maxim Vaulin");
    }
}