package inheritance;

public class Parent extends SuperParent{

       public static void add(int x, int y)   {System.out.println(x + y);}

       public static void sub(int x, int y)   {System.out.println(x - y);}

       public static void multi(int x, int y) {System.out.println(x * y);}

       public static void div(int x, int y)   {System.out.println(x / y);}

}