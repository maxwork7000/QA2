package inheritance;

public class SuperParent {

      public static void print()             {System.out.println("Example of Inheritance");}

}