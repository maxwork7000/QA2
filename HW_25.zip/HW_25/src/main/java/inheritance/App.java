package inheritance;

public class App extends Parent {

       public static void main(String[] args) {

              print();

              sub(13, 7);

              multi(5, 5);

              div(33, 1);

              add(19, 54);

       }

}