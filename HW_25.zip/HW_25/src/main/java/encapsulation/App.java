package encapsulation;

public class App {

       public static void main(String[] args) {

              Protected.setName("Alex Moore");

              System.out.println(Protected.getName());

       }

}