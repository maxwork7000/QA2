package abstraction;

abstract class AbstractClass {
       abstract void method();{System.out.println("This is Method from AbstractClass");}

}