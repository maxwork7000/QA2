package abstraction;

public class App extends AbstractClass {

       void method() {System.out.println("This is Method from App");}

       public static void main(String[] args) {new App().method();}

}